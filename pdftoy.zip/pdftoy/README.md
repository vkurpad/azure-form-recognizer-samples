pdftoy.js README

# Introductions

The content of this project is provided as a sample code, and is not part of the Microsoft Form Recognizer. 

pdftoy uses a template PDF file to help generate synthetic PDF files. This is useful to generate PDF files for training when using Microsoft Form Recognizer Custom models.

# Installations

pdftoy is written using node.js (which is a JavaScript runtime). It uses the following key open source components (MIT license):
* Faker: Generate massive amounts of fake (but realistic) data for testing and development. (https://fakerjs.dev)
* pdf-lib: Create and modify PDF documents in any JavaScript environment. (https://pdf-lib.js.org)

To use pdftoy, please install the following in your favorite operating system (Windows/Linux/MacOS)
* node.js: Install the latest LTS (Long Term Service) version from https://nodejs.org/en/
* Once node.js is installed, open your console or terminal
* Type ```npm``` to make sure that it will run without issues
* Copy all files from the zip file into a directory location with the name 'pdftoy' (or whatever of your choice)
* Go to pdftoy directory (```cd pdftoy```)
* Type ```npm install``` to install pdftoy's dependencies, such as Faker and pdf-lib
* Type ```node pdftoy.js``` to ensure that it can run and show its help text.

# Usage

## Template PDF file
pdftoy requires a PDF template file. A PDF template file contains instructions for how to generate fake data in PDF.
You can use any form-filling PDF, such as this IRS 1040 tax form https://www.irs.gov/pub/irs-pdf/f1040.pdf.
Adobe Acrobat (the paid version) also has a functionality to take any non-form-filling PDF and add a PDF form on top of it. 
It even has an auto-conversion function to help create the PDF form in an automated fashion.
Once you save the PDF file, please rename the file to be SOME_FILE_NAME.template.pdf. For example, if you download the f1040.pdf, please rename it to f1040.template.pdf.

## Auto generating labels

Open the template PDF PDF in Adobe Acrobat (free or paid version)
Edit any of the fields in the PDF and add generated data. The following field types are supported
* firstName
* lastName
* fullName
* phoneNumber
* streetAddress
* city
* st - Generating a two-letter state abbreviation
* state - Generate a full state name
* country - Generate a full country name
* zip
* dt - date supports a few variations
  * dt en-US
  * dt DD-MM-YY - For a lust of supported formats see [day.js](https://day.js.org/docs/en/display/format)

Numeric fields are supported with the number formats
* \# for a single digit. You can use formatted strings to generate a pattern, for example a social security number /#/#/#-/#/#-/#/#/#/#
* Simple numeric fields with variability in length 111999.99, where 9's are always generated, 1's are sometimes added in for variation.

Chaining fields together is simple, for example of you want to generate a city state and zip like ```Seattle WA 98001```, use the directive ```city;"  ";st;" ";zip```. Note the delimiter ```;``` after each individual command.

All content in double quotes is added in unchanged.

## Providing Faker instructions in the template PDF file
First, open the template PDF in Adobe Acrobat (free or paid version is fine here).
Click on any text field from the PDF, and add faker instructions based on what you need in that field. 

Note that faker commands need to be wrapped in curly braces

For example, if the field is for the first name, you can add the following according to Faker API [here](https://fakerjs.dev/api/name.html#firstname):
```javascript
{faker.name.firstName()}
```
Faker is very customizable. For example, per the [Faker API document](https://fakerjs.dev/api/name.html#firstname), you can generate a female name using:
```javascript
{faker.name.firstName('female')}
```

As another example, you can use the following to generate a random number from 5000 to 1000 with 2 decimal points, and a currency sign.
```javascript
{faker.finance.amount(5000, 10000, 2, '$')}
```

This can generate a string like ```$5,798.30```.

For Faker API, please see its [API doc here](https://fakerjs.dev/api/).

![Sample labels](sample.png "Sample labels")


### Create fixed custom table
In any fields that you want to create a custom table, use the following syntax:

/TABLE_NAME/ROW_NAME/COLUMN_NAME: INSTRUCTIONS

Any instruction starting with "/" will be treated as table instructions. 

For example, you want to generate a table like this:

| Applicant   | First Name | Last Name | SSN         |
|-------------|------------|-----------|-------------|
| Applicant 1 | John       | Smith     | 123-45-6712 |
| Applicant 2 | Mary       | Janes     | 246-80-1234 |


You can do the following:

| Applicant   | First Name                             | Last Name                                | SSN                                 |
|-------------|----------------------------------------|------------------------------------------|-------------------------------------|
| Applicant 1 | /AppTable/Person1/FirstName: firstName | /AppTable/Person1/LastName: lastName     | /AppTable/Person1/SSN: ###-##-##### |
| Applicant 2 | /AppTable/Person2/FirstName: firstName | /AppTable/Person2/LastName: lastName     | /AppTable/Person2/SSN: ###-##-##### |

For tables, you will often run into the character limitation of a PDF text field. Please see the section of "PDF form text field limitations."

## PDF form text field limitations

Sometimes some of the PDF forms might limit the # of the characters in a field. This prevents a full Faker instructions to be entered. There are three ways to get around this:

### Use a pdftoy shortcut string 
pdftoy allows you to specify the following shortcut so that you do not need to use faker for some common patterns:
* a format like '111999.99', and this will generate a number from 1000.00 ~ 99999.99. The digit '1' specifies the digit is not always there. And the digit '9' specifies that the a random digit from '0' ~ '9' will be always there.
* a format like '###-##-####' will generate digit 0~9 for each "#" character

### Use PDF Sticky Note
Many PDF editors allows you to add a sticky note. In the rectangle of the field that you want to add instructions, create a sticky note. Ensure that the left/top corner of the sticky note icon is inside the rectangle of the field. Put the instructions in the sticky note. 

Always edit the instructions on the first comment of the sticky notes to avoid creating a thread of sticky notes. This will cause error in pdftoy

### Enable scroll long text in text fields
* Enable 'Scroll long text' for text fields from Adobe Acrobat (Must be the paid version). Adobe Acrobat can create form-filling PDF. It allows a field to contain scrollable text, so there is no limitation on the number of characters. To do so:
  * Go to the 'Prepare Form" function in Acrobat with the PDF file
  * Right click on a field to open 'Text Field Properties' dialog.
  * Go to the 'Options' tab.
  * Ensure 'Scroll long text' is checked.

## Generate a value or a empty string based on a probability
Sometimes, it's highly desired that some field might generate data sometimes, but sometimes should be empty. pdftoy provides a helper function that you can use to do so. 

Example: 
```
p(faker.finance.amount(5000, 10000, 2, '$'), 0.8)
```

By 80% of the chances, return the faker value string which will generate a random number from 5000 to 1000 with 2 decimal points, and a currency sign. In another 20% of the chances, the function will generate an empty string.

## Save the template PDF file
Once you add all of the instructions into the fields of interest, please save the PDF file using 'SOME_FILE_NAME.template.pdf' into the same directory as pdftoy.js. Now you have the template PDF file.

## Run pdftoy with the template PDF file

If you just run pdftoy, it will provide a help screen of the full CLI (Command Line Interface) syntax.
```
node pdftoy.js
```

Assume that you save your Template PDF file in the same directory as pdftoy.js, you can start generate PDF files using this:

```
node pdftoy.js -f SOME_FILE_NAME.template.pdf  -c FILE_COUNT -o A_NEW_DIRECTORY_NAME
```

For example, the following will generate 20 files from f1040.template.pdf and save it to a new directory output01. If the output01 directory already exists, pdftoy will stop with an error message to prevent you from overwriting your previously generated files.
```
node pdftoy.js -f f1040.template.pdf -c 20 -o output01
```

After pdftoy finishes, you should be able to go to the specified output directory and review the generated PDF files. The generated PDF files will be named as SOME_FILE_NAME-NUMBER.generated.pdf. For example, the above sample will generate:
```
f1040-1.generated.pdf
f1040-2.generated.pdf
...
f1040-20.generated.pdf.
```

## Run pdftoy with the template PDF file and a template label file

If a template Form Recognizer Custom Model label file is provided, pdftoy can help generate labels.json files for each of the generated PDF file.
You can use region labeling in Form Recognizer Studio to label your template PDF file first. You can then copy the labels.json from the blob storage.
Copy the labels.json file into the same directory as your template PDF. If your template PDF file is SOME_FILE_NAME.template.pdf, then your template label file should be named as SOME_FILE_NAME.template.pdf.labels.json.

Use the '-l' or '--label' option to specify that the template label file should be used to generate a label file for each generated PDF file.
Example:
```
node pdftoy.js -f f1040.template.pdf -c 20 -o outputWithLabel -l
```

The following will be generated:
```
f1040-1.generated.pdf			
f1040-1.generated.pdf.labels.json	
f1040-2.generated.pdf
f1040-2.generated.pdf.labels.json
...
f1040-20.generated.pdf
f1040-20.generated.pdf.labels.json
```

# Development Notes

## Unit Tests
This project is set up to use jest as the unit test library. To learn about jest, see [jest Get Started](https://jestjs.io/docs/getting-started).

Please put the functions or classes that you intend to add unit test into a standalone .js file. If the file is foo.js, you can create a unit test with foo.test.js.

Please see util.js for how to export functions for unit test.

And see util.test.js for how to import functions to test, and quick examples of using jest.

In pdftoy.js, you can find the import statement for util using the name "util", which happens to be the same as the file name:
```javascript
import * as util from './util.js'
```

Here is an example of util.getTemplateBaseFileName():
```javascript
// Expect the result will be 'myfile'. Note the use of "util." due to the import statement above
const baseFileName = util.getTemplateBaseFileName('myfile.template.pdf')
```

To run the unit test, run the following under a terminal. The result should be easy to understand.
```
npm test
```

## Configure ES module for jest
jest was designed for CommonJS. However, this project is configured to be an ES module in package.json, so the dev dependency of the package "@babel/plugin-transform-modules-commonjs" and a config file .babelrc are required.
For more details, please see [How to Set Up Jest for ES Module](https://how-to.dev/how-to-set-up-jest-for-es-module).

# Feature Backlogs
* Support mutual-exclusive fields
  * For example, two checkboxes of "Yes"/"No" on the same question should only have one of the field selected
* Remove sticky notes in the PDF file
* Support dynamic tables